# Testing of RRK for IDS

import numpy as np
from  utility import *


# Main program
def main():    
    # Step 1: Parameters
    

if __name__ == "__main__":
    main()
