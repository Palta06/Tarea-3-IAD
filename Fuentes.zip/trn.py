# Training of RRK-Pinv

import numpy as np
from  utility import *


# Main program
def main():        
    # Step 1: Parameters
    X,Y,Sigma2,Lambd = load_data_csv('dtrain.csv','config.csv')
#
    

if __name__ == "__main__":
    main()
