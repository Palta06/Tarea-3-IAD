
import pandas as pd
import numpy  as np

# Data load from csv
def load_data_csv(fname):    
    return

# Create Gaussian-kernel matrix
def kernel_mtx(X1,X2,sigma2):
    return 

#  Estimating Coefficient  for KKR
def krr_coeff(K,y,lamb):    
    return beta
# calculate measures
def metricas(yv,zv):    
    return()

#Confusion matrix
def confusion_mtx(yv,zv):    
    return(cm)

